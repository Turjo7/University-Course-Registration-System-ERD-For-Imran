<?php

   $servername = "localhost";
    $username = "root";
    $password = "";                    
    $dbname = "ucrs";
    
   $department_name=$_POST['dept'];
   $course_name=$_POST['cn'];
   $course_id=$_POST['coi'];
   $credit_hour=$_POST['ch'];
   $o=$_POST['o'];
   
	
	try{
			 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "insert into course values(' ','1','$department_name','$course_name','$course_id','$credit_hour','$o');";
			 $conn->exec($stmt);
			 echo "<script>window.alert('Course Has Been Added Successfully');</script>";
			 echo "<script>window.location.assign('add_course.php');</script>";
		
	}catch(PDOException $ex){
		
		echo "<script>showalert('sign up error');</script>";
		
	}



?>