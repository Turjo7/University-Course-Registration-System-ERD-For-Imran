<?php

   $servername = "localhost";
    $username = "root";
    $password = "";                    
    $dbname = "ucrs";
    
   $student_name=$_POST['sn'];
   $student_id=$_POST['sui'];
   $department=$_POST['dept'];
   $batch=$_POST['batch'];
   
	
	try{
			 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "insert into student values(' ','1','$student_name','$student_id','1234','$department','$batch');";
			 $conn->exec($stmt);
			 echo "<script>window.alert('Student Has Been Added Successfully');</script>";
			 echo "<script>window.location.assign('add_student.php');</script>";
		
	}catch(PDOException $ex){
		
		echo "<script>showalert('sign up error');</script>";
		
	}



?>