<?php

   $servername = "localhost";
    $username = "root";
    $password = "";                    
    $dbname = "ucrs";
    
   $cc_id=$_POST['cc_id'];
   #$course_name=$_POST['cn'];
   #$course_id=$_POST['cid'];
   #$credit_hour=$_POST['ch'];
   #$o=$_POST['o'];
   #$student_id=$_POST['student_id'];
   #$a=implode($in);
   #0 means the course been taken but not registered
   #1 means the admin have approved the courses and registered
   
	
	try{
			 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "DELETE FROM coursecart WHERE cc_id='$cc_id'";
			 $conn->exec($stmt);
			 echo "<script>window.alert('Course Has Been Removed Successfully By The Student');</script>";
			 echo "<script>window.location.assign('cr.php');</script>";
		
	}catch(PDOException $ex){
		
		echo "<script>showalert('sign up error');</script>";
		
	}



?>