<?php

   $servername = "localhost";
    $username = "root";
    $password = "";                    
    $dbname = "ucrs";
    
   $department_name=$_POST['dn'];
   $course_name=$_POST['cn'];
   $course_id=$_POST['cid'];
   $credit_hour=$_POST['ch'];
   $o=$_POST['o'];
   $student_id=$_POST['student_id'];
   #$a=implode($in);
   #0 means the course been taken but not registered
   #1 means the admin have approved the courses and registered
   
	
	try{
			 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "insert into coursecart values(' ','1','$student_id','$department_name','$course_name','$course_id','$credit_hour','$o','0');";
			 $conn->exec($stmt);
			 echo "<script>window.alert('Course Has Been Added Successfully By The Student');</script>";
			 echo "<script>window.location.assign('take_course.php');</script>";
		
	}catch(PDOException $ex){
		
		echo "<script>showalert('sign up error');</script>";
		
	}



?>