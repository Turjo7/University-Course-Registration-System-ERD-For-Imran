<?php

   $servername = "localhost";
    $username = "root";
    $password = "";                    
    $dbname = "ucrs";
    
   $course_final=$_POST['cc_id'];
   
   
	
	try{
			 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "UPDATE coursecart SET reg_status='1' WHERE cc_id='$course_final'";
			 $conn->exec($stmt);
			 echo "<script>window.alert('Course Registed Successfully!!!!');</script>";
			 echo "<script>window.location.assign('acr.php');</script>";
		
	}catch(PDOException $ex){
		
		echo "<script>showalert('sign up error');</script>";
		
	}



?>