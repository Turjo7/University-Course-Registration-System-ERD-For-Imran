<?php

   $servername = "localhost";
    $username = "root";
    $password = "";                    
    $dbname = "ucrs";
    
   $course_remove=$_POST['cid'];
   
   
	
	try{
			 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "DELETE FROM course WHERE c_id='$course_remove'";
			 $conn->exec($stmt);
			 echo "<script>window.alert('Course Has Been Removed Successfully');</script>";
			 echo "<script>window.location.assign('add_course.php');</script>";
		
	}catch(PDOException $ex){
		
		echo "<script>showalert('sign up error');</script>";
		
	}



?>