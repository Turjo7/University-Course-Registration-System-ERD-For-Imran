<?php

   $servername = "localhost";
    $username = "root";
    $password = "";                    
    $dbname = "ucrs";
    
   $student_remove=$_POST['adv'];
   
   
	
	try{
			 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "DELETE FROM student WHERE s_id='$student_remove'";
			 $conn->exec($stmt);
			 echo "<script>window.alert('Student Has Been Removed Successfully');</script>";
			 echo "<script>window.location.assign('add_student.php');</script>";
		
	}catch(PDOException $ex){
		
		echo "<script>showalert('sign up error');</script>";
		
	}



?>